import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  
  constructor(private http: HttpClient) { }
 
  getData() {
    console.info("calling...")
    return this.http.get('./assets/living-room.json')
  }
}

