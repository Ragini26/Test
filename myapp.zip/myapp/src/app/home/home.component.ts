import { Component, OnInit } from '@angular/core';
import { ProductService } from '../service/product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  livingRoomData: Object;


  constructor(
    private productService : ProductService
  ) { }

  ngOnInit(): void {
    this.productService.getData().subscribe(data=>{
     this.livingRoomData = data;
     console.log(data);
    })
  }

}
